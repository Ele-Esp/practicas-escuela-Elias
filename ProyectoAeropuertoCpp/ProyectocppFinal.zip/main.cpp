#include <iostream>
#include "Sistema.h"


using namespace std;
//ejecutar con g++ *.cpp  -o main.exe
//Hecho por Elías Rodríguez Hernández A01654900 para entrega el 17/06/2022
//Clase del tecnológico de monterrey campus CCM programación orientada a objetos. 

int main() {
    cout<< "Hello Worl!d!" << endl;
    Sistema smain;
    return 0;

}